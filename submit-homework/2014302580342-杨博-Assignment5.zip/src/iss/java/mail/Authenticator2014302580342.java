package iss.java.mail;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class Authenticator2014302580342 extends Authenticator{

	private String userName;
	private String passWord;
	
	public Authenticator2014302580342(String u,String p){
		this.userName = u;
		this.passWord = p;
	}
	protected PasswordAuthentication getPasswordAuthentication() 
    {
        return new PasswordAuthentication(userName, passWord);
    }
    
    
	public String  getUserName(){
		return userName;
	}
	public String getpassWord(){
		return passWord;
	}
}
